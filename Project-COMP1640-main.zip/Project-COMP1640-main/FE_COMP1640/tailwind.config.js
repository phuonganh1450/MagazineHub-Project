/** @type {import('tailwindcss').Config} */
export const content = ["./src/**/*.{html,js,tsx,jsx}"];
export const theme = {
   extend: {},
};
export const plugins = [];
