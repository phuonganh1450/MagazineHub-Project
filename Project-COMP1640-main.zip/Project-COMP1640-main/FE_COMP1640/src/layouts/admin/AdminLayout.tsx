import { Outlet } from "react-router-dom";
import Sidebar from "../../components/Sidebar/Sidebar";
import Topbar from "../../components/Topbar/Topbar";

function AdminLayout() {
   // const { appSelector } = useRedux();
   // const { isOpen } = appSelector((state) => state.layout);

   return (
      <div className="w-full h-full flex bg-bgPrimar">
         {/* <div className="">{isOpen && <Sidebar />}</div> */}
         <Sidebar />
         <div className="flex-1 bg-slate-100 h-screen overflow-y-scroll relative">
            <Topbar />
            <div className="xl:w-[1200px] xl:mt-12 pb-20  flex-1 mx-auto">
               <Outlet />
            </div>
         </div>
      </div>
   );
}

export default AdminLayout;
