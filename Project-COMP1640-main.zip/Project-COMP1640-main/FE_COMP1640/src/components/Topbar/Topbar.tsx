function Topbar() {
   return (
      <div className="h-20 sticky bg-white top-0 left-0 right-0 z-50 border-b ">
         <div className="w-[1200px] flex h-full justify-end">
            {/* <UserProfile /> */}
         </div>
      </div>
   );
}

export default Topbar;
