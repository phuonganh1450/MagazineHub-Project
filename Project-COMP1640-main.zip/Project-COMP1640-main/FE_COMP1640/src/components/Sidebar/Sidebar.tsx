import React, { useEffect, useState } from "react";
import { NavItem, NavItemDropdownProps } from "./Sidebar.type";
import { text } from "stream/consumers";
import { Link, useLocation } from "react-router-dom";
import {
   ChevronDownIcon,
   ChevronRightIcon,
   FilmIcon,
   MinusIcon,
   UsersIcon,
   VideoCameraIcon,
} from "@heroicons/react/24/outline";
import { ChartBarIcon } from "@heroicons/react/24/solid";
import { PATHS } from "../../constants/path";

function Sidebar() {
   const location = useLocation();
   const [active, setActive] = useState<string>("");

   useEffect(() => {
      setActive(location.pathname);
   }, [location]);

   const navItems: NavItem[] = [
      {
         text: "Thống kê",
         icon: ChartBarIcon,
         // to: PATHS.ADMIN.DASHBOARD.IDENTITY,
      },
      {
         text: "Phim",
         icon: FilmIcon,
         // to: PATHS.ADMIN.MOVIES.IDENTITY,
      },
      {
         text: "Rạp",
         icon: VideoCameraIcon,
         children: [
            {
               text: "Hệ thống rạp",
               // to: PATHS.ADMIN.CINEMA.IDENTITY,
            },
            {
               text: "Suất chiếu",
               // to: PATHS.ADMIN.SHOWTIMES.IDENTITY,
            },
         ],
      },
      {
         text: "Người dùng",
         icon: UsersIcon,
         children: [
            {
               text: "Thông tin",
               // to: PATHS.ADMIN.USERS.IDENTITY,
            },
            {
               text: "Bình luận",
               // to: PATHS.ADMIN.COMMENTS.IDENTITY,
            },
         ],
      },
   ];

   return (
      <div className="bg-white w-[250px] min-h-screen border text-sm border-r ">
         <div className="w-full text-center py-5">
            <Link to={`/${PATHS.HOME.IDENTITY}`} replace>
               <h1 className="font-semibold text-lg">Logo</h1>
            </Link>
         </div>
         <div className="w-full">
            {/* <ul className="flex flex-col px-6 gap-[10px]">
               {navItems.map((item: NavItem, index: number) => {
                  return (
                     <NavItemDropdown
                        key={`nav-item-${index}`}
                        item={item}
                        active={active}
                     />
                  );
               })}
            </ul> */}
         </div>
      </div>
   );
}

export default Sidebar;
