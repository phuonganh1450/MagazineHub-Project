import clsx from "clsx";
import { FieldErrors, FieldValues, UseFormRegister } from "react-hook-form";
import { useEffect, useState } from "react";

interface InputProps {
   label: string;
   id: string;
   type?: string;
   required?: boolean;
   register?: UseFormRegister<FieldValues>;
   errors?: FieldErrors;
   disabled?: boolean;
   placeholder?: string;
   value?: string;
   style?: string;
   accept?: string;
}
const Input = ({
   label,
   id,
   type,
   required,
   register,
   errors,
   disabled,
   placeholder,
   value,
   style,
   accept,
}: InputProps) => {
   const [inputValue, setInputValue] = useState(value);
   useEffect(() => {
      setInputValue(value);
   }, [value]);

   return (
      <>
         <div className={clsx("mb-3", style?.toString())}>
            <label htmlFor={id} className="text-gray-800 text-sm font-normal">
               {label}
            </label>

            <div
               className={clsx(
                  "border mt-1 rounded overflow-hidden",
                  errors?.[id] && "border-rose-500 outline-rose-500 ring-0",
               )}
            >
               <input
                  id={id}
                  type={type}
                  disabled={disabled}
                  placeholder={placeholder}
                  autoComplete="new-password"
                  defaultValue={inputValue}
                  accept={accept || "text"}
                  {...(register && register(id, { required }))}
                  className={clsx(
                     "w-full rounded outline-gray-700 placeholder:font-normal placeholder:text-sm",
                     errors?.[id] && "border-rose-500 outline-rose-500 ring-0",
                     type === "file"
                        ? `p-0 file:mr-4 file:py-2 file:px-4 file:rounded-s-none file:border-0   
                        file:text-sm file:font-semibold file:bg-blue-100 file:text-blue-600 
                      hover:file:bg-blue-100 text-slate-400 placeholder:text-xs text-sm`
                        : "p-2",
                  )}
               />
            </div>
            {errors?.[id] && (
               <span className="text-red-500 text-xs">
                  *{errors?.[id]?.message?.toString()}
               </span>
            )}
         </div>
      </>
   );
};
export default Input;
