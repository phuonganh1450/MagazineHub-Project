import Input from "../../../components/CustomInput";
import * as yup from "yup";
import { FieldValues, SubmitHandler, useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";

const schema = yup.object().shape({
   title: yup.string().required("Title is required"),
   description: yup.string().required("Description is required"),
   image: yup
      .mixed<FileList>()
      .test("require", "Upload your image", (files) => {
         return !!files?.[0];
      })
      .test("fileType", "Unsupported file format", (files) => {
         return (
            !files ||
            files?.[0]?.type === "image/jpg" ||
            files?.[0]?.type === "image/png" ||
            files?.[0]?.type === "image/webp" ||
            files?.[0]?.type === "image/jpeg"
         );
      })
      .test("fileSize", "File size is too large", (files) => {
         return !files || files?.[0]?.size < 5000000;
      }),

   document: yup
      .mixed<FileList>()
      .test("require", "Upload your document", (files) => {
         return !!files?.[0];
      })
      .test(
         "fileSize",
         "File size is too large",
         (files) => files && files?.[0]?.size <= 10000000,
      )
      .test(
         "fileType",
         "Unsupported file format",
         (value) =>
            value &&
            (value?.[0]?.type === "application/msword" ||
               value?.[0]?.type ===
                  "application/vnd.openxmlformats-officedocument.wordprocessingml.document"),
      ),
});

const UploadForm = () => {
   const {
      register,
      handleSubmit,
      formState: { errors },
   } = useForm<FieldValues>({
      resolver: yupResolver<FieldValues>(schema),
   });

   const onSubmit: SubmitHandler<FieldValues> = (data) => {
      console.log(data);
      // Handle form submission here
   };
   return (
      <div className="max-w-lg mx-auto bg-white p-6 rounded-lg shadow-xl">
         <h1 className="text-2xl font-semibold mb-6 text-gray-700">
            Contribution Upload
         </h1>
         <form onSubmit={handleSubmit(onSubmit)} encType="multipart/form-data">
            <Input
               register={register}
               errors={errors}
               required
               id="title"
               label="Title"
               type="text"
            ></Input>
            <Input
               register={register}
               errors={errors}
               required
               id="description"
               label="Description"
               type="text"
            ></Input>
            <Input
               register={register}
               errors={errors}
               required
               id="image"
               label="Image"
               type="file"
               accept="image/*"
            ></Input>
            <Input
               register={register}
               errors={errors}
               required
               id="document"
               label="Document"
               type="file"
               accept=".docx, .doc, .pdf"
            ></Input>

            <button
               type="submit"
               className="w-full mt-2 bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600"
            >
               Submit
            </button>
         </form>
      </div>
   );
};

export default UploadForm;
