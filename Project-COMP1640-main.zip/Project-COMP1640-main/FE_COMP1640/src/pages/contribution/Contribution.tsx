import React from "react";
import UploadForm from "./components/UploadForm";

const Contribution = () => {
   return (
      <div className="min-h-screen min-w-screen px-2">
         <UploadForm />
      </div>
   );
};

export default Contribution;
