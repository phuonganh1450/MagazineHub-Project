const PATHS = {
   HOME: {
      IDENTITY: "",
   },
   AUTH: {
      IDENTIFY: "auth",
      LOGIN: "login",
      REGISTER: "register",
   },
   CONTRIBUTION: {
      IDENTIFY: "contribution",
   },
   ADMIN: {
      IDENTIFY: "admin",
   },
};

export { PATHS };
