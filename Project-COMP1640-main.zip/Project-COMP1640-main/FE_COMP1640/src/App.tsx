import Routers from "./routes/routes";

export default function App() {
   return <Routers />;
}
