﻿namespace Domain.Enums
{
    public enum MediaType
    {
        Image = 0,
        Document = 1
    }
}
