﻿using Application.Features.Contributions.Queries.ListContribution;
using Sieve.Services;

namespace API.Sieve.Configurations
{
    public class ListContributionDtoSieveConfiguration : ISieveConfiguration
    {
        public void Configure(SievePropertyMapper mapper)
        {
            mapper.Property<ListContributionDto>(c => c.Title)
                .CanFilter()
                .CanSort();

            mapper.Property<ListContributionDto>(c => c.Description)
                .CanFilter()
                .CanSort();

            mapper.Property<ListContributionDto>(c => c.CreatedAt)
                .CanFilter()
                .CanSort();

            mapper.Property<ListContributionDto>(c => c.LastModifiedAt)
                .CanFilter()
                .CanSort();

            mapper.Property<ListContributionDto>(c => c.CreatedByEmail)
                .CanFilter()
                .CanSort();

        }
    }
}
