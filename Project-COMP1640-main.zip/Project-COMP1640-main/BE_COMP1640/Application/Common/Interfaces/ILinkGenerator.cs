﻿namespace Application.Common.Interfaces
{
    public interface ILinkGenerator
    {
        string GenerateLink(string url);
    }
}
